Download datasets from the google drive links and place them in this directory. Your directory structure should look something like this
  
  `Synthetic_Rain_Datasets` <br/>
  `├──`[train](https://drive.google.com/drive/folders/1RzMgqO3x0aHpBMYf-C4TI_0f0K9DfyLu?usp=drive_link)  <br/>
   ├──`[validation](https://drive.google.com/drive/folders/13Py0YFk1H2pFSF1MIUoSHoAwtwjwXrcH?usp=drive_link)  <br/>
   └──`[test](https://drive.google.com/drive/folders/1300oiuof6OIM4K6_XCqBYzp4hVNVSplO?usp=drive_link)  <br/>
      
